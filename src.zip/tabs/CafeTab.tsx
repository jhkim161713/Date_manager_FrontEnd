import { useState } from "react"
import { SectionTitle } from "../components/SectionTitle"
import { HScroll } from "../components/HScroll"
import { CAFES } from "../data/CafeData"
import { ContentCard } from "../components/ContentCard"
import { Badge } from "../components/Badge"


export function CafeTab() {
  return (
    <div className="space-y-6">
      <SectionTitle sub="감성 넘치는 카페 탐방">☕ 카페 추천</SectionTitle>
      <HScroll>
        {CAFES.map(c => <ContentCard key={c.id} item={c} />)}
      </HScroll>
      <div className="grid grid-cols-2 gap-3">
        {CAFES.map(c => (
          <div key={c.id} className="rounded-2xl overflow-hidden bg-white hover:scale-[1.02] transition-transform cursor-pointer"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="h-28 bg-pink-100">
              <img src={c.img} alt={c.title} className="w-full h-full object-cover" />
            </div>
            <div className="p-3">
              <Badge color={c.tagColor} bg={c.tagBg}>{c.tag}</Badge>
              <p className="font-bold text-sm mt-1.5" style={{ color: '#3d2c35' }}>{c.title}</p>
              <p className="text-xs text-stone-400 mt-0.5">📍 {c.location}</p>
              <p className="text-xs font-bold mt-1" style={{ color: '#ff6b8a' }}>♥ {c.match}%</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}