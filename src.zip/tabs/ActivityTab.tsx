import { useState } from "react"
import { SectionTitle } from "../components/SectionTitle"
import { HScroll } from "../components/HScroll"
import { ACTIVITIES } from "../data/ActivityData"
import { ContentCard } from "../components/ContentCard"
import { Badge } from "../components/Badge"

export function ActivityTab() {
  return (
    <div className="space-y-6">
      <SectionTitle sub="기억에 남을 특별한 체험">🌿 액티비티 추천</SectionTitle>
      <HScroll>
        {ACTIVITIES.map(a => <ContentCard key={a.id} item={a} wide />)}
      </HScroll>
      <div className="space-y-3">
        {ACTIVITIES.map(a => (
          <div key={a.id} className="rounded-2xl bg-white flex items-center gap-4 p-4 hover:scale-[1.01] transition-transform cursor-pointer"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-pink-100">
              <img src={a.img} alt={a.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <Badge color={a.tagColor} bg={a.tagBg}>{a.tag}</Badge>
              <p className="font-bold text-sm mt-1" style={{ color: '#3d2c35' }}>{a.title}</p>
              <p className="text-xs text-stone-400">📍 {a.location} · 💰 {a.price}</p>
            </div>
            <span className="text-sm font-bold flex-shrink-0" style={{ color: '#ff6b8a' }}>♥ {a.match}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}