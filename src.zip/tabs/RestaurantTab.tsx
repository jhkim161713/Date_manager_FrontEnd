import { useState } from "react";
import { RESTAURANTS } from "../data/restaurantData";
import { SectionTitle } from "../components/SectionTitle";
import { HScroll } from "../components/HScroll";
import { ContentCard } from "../components/ContentCard";
import { Badge } from "../components/Badge";


export function RestaurantTab() {
  const tags = ['전체', '일식', '이탈리안', '한식', '프렌치']
  const [filter, setFilter] = useState('전체')
  const filtered = filter === '전체' ? RESTAURANTS : RESTAURANTS.filter(r => r.tag === filter)
  return (
    <div className="space-y-6">
      <SectionTitle sub="특별한 날을 위한 레스토랑">🍽️ 맛집 추천</SectionTitle>
      <div className="flex gap-2 flex-wrap">
        {tags.map(t => (
          <button key={t} onClick={() => setFilter(t)}
            className="rounded-full px-3 py-1 text-xs font-bold transition-all"
            style={{ background: filter === t ? '#ff6b8a' : '#fff0f3', color: filter === t ? 'white' : '#ff6b8a', border: '1.5px solid #ffd6e0' }}>
            {t}
          </button>
        ))}
      </div>
      <HScroll>
        {filtered.map(r => <ContentCard key={r.id} item={r} wide />)}
      </HScroll>
      <div className="space-y-3">
        {filtered.map(r => (
          <div key={r.id} className="rounded-2xl bg-white flex items-center gap-4 p-4 hover:scale-[1.01] transition-transform cursor-pointer"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-pink-100">
              <img src={r.img} alt={r.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <Badge color={r.tagColor} bg={r.tagBg}>{r.tag}</Badge>
              <p className="font-bold text-sm mt-1" style={{ color: '#3d2c35' }}>{r.title}</p>
              <p className="text-xs text-stone-400">📍 {r.location} · {r.price}</p>
            </div>
            <span className="text-sm font-bold flex-shrink-0" style={{ color: '#ff6b8a' }}>♥ {r.match}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}