import { EXHIBITIONS } from "../data/exhibitionData";
import { SectionTitle } from "../components/SectionTitle";
import { HScroll } from "../components/HScroll";
import { ContentCard } from "../components/ContentCard";
import { Badge } from "../components/Badge";


export function ExhibitionTab() {
  return (
    <div className="space-y-6">
      <SectionTitle sub="지금 가볼 만한 전시">🎨 전시 추천</SectionTitle>
      <div className="rounded-2xl p-4" style={{ background: 'linear-gradient(135deg, #f5eef9, #fff0f3)', border: '1.5px solid #e8d5f5' }}>
        <p className="text-xs font-bold" style={{ color: '#c4a0e8' }}>💡 이런 커플에게 추천</p>
        <p className="text-sm font-semibold mt-1" style={{ color: '#3d2c35' }}>예술 감성이 풍부한 문화탐험형 커플에게 딱!</p>
      </div>
      <HScroll>
        {EXHIBITIONS.map(e => <ContentCard key={e.id} item={e} wide />)}
      </HScroll>
      <div className="space-y-3">
        {EXHIBITIONS.map(e => (
          <div key={e.id} className="rounded-2xl p-4 bg-white flex items-center gap-4 hover:scale-[1.01] transition-transform cursor-pointer"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-pink-100">
              <img src={e.img} alt={e.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <Badge color={e.tagColor} bg={e.tagBg}>{e.tag}</Badge>
              </div>
              <p className="font-bold text-sm" style={{ color: '#3d2c35' }}>{e.title}</p>
              <p className="text-xs text-stone-400">📍 {e.location} · 🎫 {e.price}</p>
            </div>
            <span className="text-sm font-bold" style={{ color: '#ff6b8a' }}>♥ {e.match}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}