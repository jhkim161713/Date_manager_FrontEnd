import { useState } from "react";
import { MOVIES } from "../data/movieData";
import { SectionTitle } from "../components/SectionTitle";
import { Badge } from "../components/Badge";



export function MovieTab() {
  const genres = ['전체', '로맨스', '감성', '뮤지컬', '멜로', '공감']
  const [filter, setFilter] = useState('전체')
  const filtered = filter === '전체' ? MOVIES : MOVIES.filter(m => m.tag === filter)
  return (
    <div className="space-y-6">
      <SectionTitle sub="커플 취향에 맞는 영화">🎬 영화 추천</SectionTitle>
      <div className="flex gap-2 flex-wrap">
        {genres.map(g => (
          <button key={g} onClick={() => setFilter(g)}
            className="rounded-full px-3 py-1 text-xs font-bold transition-all"
            style={{ background: filter === g ? '#ff6b8a' : '#fff0f3', color: filter === g ? 'white' : '#ff6b8a', border: '1.5px solid #ffd6e0' }}>
            {g}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {filtered.map(m => (
          <div key={m.id} className="rounded-2xl overflow-hidden flex hover:scale-[1.01] transition-transform cursor-pointer bg-white"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="w-24 h-24 flex-shrink-0 bg-pink-100">
              <img src={m.img} alt={m.title} className="w-full h-full object-cover" />
            </div>
            <div className="p-3.5 flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Badge color={m.tagColor} bg={m.tagBg}>{m.tag}</Badge>
                <span className="text-xs font-bold" style={{ color: '#ff6b8a' }}>♥ {m.match}%</span>
              </div>
              <p className="font-bold text-sm" style={{ color: '#3d2c35' }}>{m.title}</p>
              <p className="text-xs text-stone-400 mt-0.5">{m.subtitle}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}