import { useState } from "react";
import { SectionTitle } from "../components/SectionTitle";
import { HScroll } from "../components/HScroll";
import { ContentCard } from "../components/ContentCard";
import { Badge } from "../components/Badge";
import { CONCERTS } from "../data/concertData";


export function ConcertTab() {
  return (
    <div className="space-y-6">
      <SectionTitle sub="함께 즐기는 공연·음악">🎵 공연 추천</SectionTitle>
      <HScroll>
        {CONCERTS.map(c => <ContentCard key={c.id} item={c} wide />)}
      </HScroll>
      <div className="space-y-3">
        {CONCERTS.map(c => (
          <div key={c.id} className="rounded-2xl bg-white flex items-center gap-4 p-4 hover:scale-[1.01] transition-transform cursor-pointer"
            style={{ border: '1.5px solid #ffd6e0' }}>
            <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-pink-100">
              <img src={c.img} alt={c.title} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0">
              <Badge color={c.tagColor} bg={c.tagBg}>{c.tag}</Badge>
              <p className="font-bold text-sm mt-1" style={{ color: '#3d2c35' }}>{c.title}</p>
              <p className="text-xs text-stone-400">📍 {c.location} · 🎫 {c.price}</p>
            </div>
            <span className="text-sm font-bold flex-shrink-0" style={{ color: '#ff6b8a' }}>♥ {c.match}%</span>
          </div>
        ))}
      </div>
    </div>
  )
}