import {Tab} from '../types';

export interface TabConfig{
    id: Tab;
    label: string;
    emoji: string;
}


export const TABS: TabConfig[] = [
  { id: 'home',       label: '홈',      emoji: '🏠' },
  { id: 'tendency',   label: '성향테스트', emoji: '💡' },
  { id: 'movie',      label: '영화',    emoji: '🎬' },
  { id: 'exhibition', label: '전시',    emoji: '🎨' },
  { id: 'restaurant', label: '맛집',    emoji: '🍽️' },
  { id: 'concert',    label: '공연',    emoji: '🎵' },
  { id: 'cafe',       label: '카페',    emoji: '☕' },
  { id: 'activity',   label: '액티비티', emoji: '🌿' },
  { id: 'tarot',   label: '타로', emoji: '🔮' },
  { id: 'calender',   label: '캘린더', emoji: '📅' },
  { id: 'magazine',   label: '매거진', emoji: '📖' },
]
