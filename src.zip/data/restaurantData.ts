import { CurationCard } from "../types"

export const RESTAURANTS: CurationCard[] = [
  { id: 1, title: '오마카세 스시 사쿠라', subtitle: '코스 오마카세 · 예약 필수', tag: '일식', tagColor: '#ff6b8a', tagBg: '#fff0f3', match: 96, img: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=300&fit=crop&auto=format', location: '청담동', price: '150,000원~' },
  { id: 2, title: '루프탑 이탈리안 라 루나', subtitle: '야경과 파스타의 만남', tag: '이탈리안', tagColor: '#c4a0e8', tagBg: '#f5eef9', match: 93, img: 'https://images.unsplash.com/photo-1663530761401-15eefb544889?w=400&h=300&fit=crop&auto=format', location: '한남동', price: '60,000원~' },
  { id: 3, title: '한정식 고가',           subtitle: '전통 한옥에서 즐기는 한정식', tag: '한식', tagColor: '#f9a030', tagBg: '#fff8e6', match: 90, img: 'https://images.unsplash.com/photo-1641124962413-4eee4dff807e?w=400&h=300&fit=crop&auto=format', location: '북촌', price: '80,000원~' },
  { id: 4, title: '프렌치 비스트로 몽마르트', subtitle: '파리 감성의 정통 프렌치', tag: '프렌치', tagColor: '#4dbfa8', tagBg: '#e6f9f5', match: 87, img: 'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=400&h=260&fit=crop&auto=format', location: '서래마을', price: '70,000원~' },
]
