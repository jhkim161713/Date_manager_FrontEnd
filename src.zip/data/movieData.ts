import { CurationCard } from "../types"

export const MOVIES: CurationCard[] = [
  { id: 1, title: '비포 선라이즈', subtitle: '1995 · 로맨스 · 감성 여행',      tag: '로맨스', tagColor: '#ff6b8a', tagBg: '#fff0f3', match: 98, img: 'https://images.unsplash.com/photo-1622296571436-8d5b1c203416?w=400&h=300&fit=crop&auto=format' },
  { id: 2, title: '어바웃 타임',   subtitle: '2013 · 로맨스 · 타임슬립',      tag: '감성',   tagColor: '#c4a0e8', tagBg: '#f5eef9', match: 95, img: 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=400&h=300&fit=crop&auto=format' },
  { id: 3, title: '라라랜드',      subtitle: '2016 · 뮤지컬 · 꿈과 사랑',     tag: '뮤지컬', tagColor: '#f9a030', tagBg: '#fff8e6', match: 93, img: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400&h=300&fit=crop&auto=format' },
  { id: 4, title: '노트북',        subtitle: '2004 · 멜로 · 순수한 사랑',      tag: '멜로',   tagColor: '#ff6b8a', tagBg: '#fff0f3', match: 90, img: 'https://images.unsplash.com/photo-1563841930606-67e2bce48b78?w=400&h=300&fit=crop&auto=format' },
  { id: 5, title: '500일의 썸머',  subtitle: '2009 · 로맨스 · 현실적 연애',   tag: '공감',   tagColor: '#4dbfa8', tagBg: '#e6f9f5', match: 88, img: 'https://images.unsplash.com/photo-1682985045797-0b781d0c0f7a?w=400&h=300&fit=crop&auto=format' },
]