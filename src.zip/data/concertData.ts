import { CurationCard } from "../types";

export const CONCERTS: CurationCard[] = [
  { id: 1, title: '재즈나이트 블루문',    subtitle: '라이브 재즈 + 칵테일',       tag: '재즈',   tagColor: '#f9a030', tagBg: '#fff8e6', match: 95, img: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400&h=300&fit=crop&auto=format', location: '이태원', price: '30,000원' },
  { id: 2, title: '클래식 봄밤 콘서트',   subtitle: '서울시향 실내악 시리즈',      tag: '클래식', tagColor: '#c4a0e8', tagBg: '#f5eef9', match: 92, img: 'https://images.unsplash.com/photo-1563841930606-67e2bce48b78?w=400&h=300&fit=crop&auto=format', location: '예술의전당', price: '50,000원' },
  { id: 3, title: '뮤지컬 웨스트사이드', subtitle: '브로드웨이 라이선스 공연',     tag: '뮤지컬', tagColor: '#ff6b8a', tagBg: '#fff0f3', match: 89, img: 'https://images.unsplash.com/photo-1459749411175-04bf5292ceea?w=400&h=260&fit=crop&auto=format', location: '충무아트센터', price: '80,000원' },
  { id: 4, title: '인디밴드 페스티벌',    subtitle: '감성 인디 라이브 한마당',     tag: '인디',   tagColor: '#4dbfa8', tagBg: '#e6f9f5', match: 86, img: 'https://images.unsplash.com/photo-1563841930606-67e2bce48b78?w=400&h=260&fit=crop&auto=format', location: '홍대 롤링홀', price: '25,000원' },
]