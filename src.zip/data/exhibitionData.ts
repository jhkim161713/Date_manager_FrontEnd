import { CurationCard } from "../types";

export const EXHIBITIONS: CurationCard[] = [
  { id: 1, title: '빛: 영혼의 언어',   subtitle: '인터랙티브 미디어아트전',    tag: '미디어아트', tagColor: '#c4a0e8', tagBg: '#f5eef9', match: 97, img: 'https://images.unsplash.com/photo-1606819717115-9159c900370b?w=400&h=300&fit=crop&auto=format', location: '동대문 DDP', price: '19,000원' },
  { id: 2, title: '모네에서 마티스까지', subtitle: '인상주의 거장 특별전',      tag: '회화',      tagColor: '#ff6b8a', tagBg: '#fff0f3', match: 94, img: 'https://images.unsplash.com/photo-1518998053901-5348d3961a04?w=400&h=300&fit=crop&auto=format', location: '예술의전당', price: '22,000원' },
  { id: 3, title: '사진으로 보는 지구',  subtitle: '내셔널지오그래픽 사진전',   tag: '사진',      tagColor: '#f9a030', tagBg: '#fff8e6', match: 90, img: 'https://images.unsplash.com/photo-1569783721854-33a99b4c0bae?w=400&h=300&fit=crop&auto=format', location: '성수동 갤러리', price: '15,000원' },
  { id: 4, title: '거울의 방',          subtitle: '설치미술 몰입형 체험전',    tag: '설치',      tagColor: '#4dbfa8', tagBg: '#e6f9f5', match: 88, img: 'https://images.unsplash.com/photo-1606819717115-9159c900370b?w=400&h=260&fit=crop&auto=format', location: '홍대 아트센터', price: '18,000원' },
]