export type Tab = 'home' | 'movie' | 'exhibition' | 'restaurant' | 'concert' | 'cafe' | 'activity' | 'tendency'| 'tarot' | 'calender' | 'magazine'


export interface CurationCard {
  id: number
  title: string
  subtitle: string
  tag: string
  tagColor: string
  tagBg: string
  match: number
  img: string
  location?: string
  price?: string
}

export type QuickCategory = '전체' | '문화' | '맛집' | '숙소';